from django.contrib import admin
from .models import admin_registration
# Register your models here.
admin.site.register(admin_registration)