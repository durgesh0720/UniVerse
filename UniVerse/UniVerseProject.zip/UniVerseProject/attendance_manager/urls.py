from django.urls import path
from . import views as attendanceViews

urlpatterns=[
    # path('attendance-manager/',attendanceViews.attendanceManager,name='attendaneHome'),
    # path('attendance-update/',attendanceViews.updateAttendance),
    # path('attendance-add/',attendanceViews.addAttendance),
]