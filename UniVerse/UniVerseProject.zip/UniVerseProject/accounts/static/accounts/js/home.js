gsap.from("#hero h1", { duration: 1, opacity: 0, y: -50, ease: "power4.out" });
        gsap.from("#hero p", { duration: 1, opacity: 0, y: 30, delay: 0.5, ease: "power4.out" });
        gsap.from("#actions", { duration: 1, opacity: 0, y: 30, delay: 1, ease: "power4.out" });
        gsap.from("#quotes blockquote", { duration: 1, opacity: 0, y: 50, stagger: 0.3, delay: 1.5, ease: "power4.out" });