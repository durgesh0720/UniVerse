from django.contrib import admin
from .models import student_registration
# Register your models here.
admin.site.register(student_registration)