from django.urls import path
from . import views

urlpatterns=[
    # path('assignment-manager/',views.assignment_home,name='assignment-home'),
    # path('upload-assignment/',views.upload_assignment,name='upload-assignment'),
]